
import yfinance as yf
import matplotlib.pyplot as plt
import pandas as pd

class EnhancedTradingBot:
    def __init__(self, stock_symbol, start_date, end_date):
        self.stock_symbol = stock_symbol
        self.start_date = start_date
        self.end_date = end_date
        self.data = None

    def fetch_stock_data(self):
        self.data = yf.download(self.stock_symbol, start=self.start_date, end=self.end_date)
        if self.data.empty:
            print("No data found for the given stock symbol.")
        else:
            print(f"Fetched data for {self.stock_symbol}")

    def calculate_indicators(self):
        if self.data is None or self.data.empty:
            print("No data to calculate indicators. Fetch data first.")
            return

        self.data['Short_MA'] = self.data['Close'].rolling(window=20).mean()
        self.data['Long_MA'] = self.data['Close'].rolling(window=50).mean()
        delta = self.data['Close'].diff(1)
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        avg_gain = gain.rolling(window=14).mean()
        avg_loss = loss.rolling(window=14).mean()
        rs = avg_gain / avg_loss
        self.data['RSI'] = 100 - (100 / (1 + rs))

    def plot_enhanced_graph(self):
        if self.data is None or self.data.empty:
            print("No data to plot. Fetch data first.")
            return

        plt.figure(figsize=(14, 8))

        plt.subplot(2, 1, 1)
        plt.plot(self.data['Close'], label='Close Price', color='blue')
        plt.plot(self.data['Short_MA'], label='Short Moving Average (20)', color='orange')
        plt.plot(self.data['Long_MA'], label='Long Moving Average (50)', color='red')
        plt.title(f"Enhanced Trading Graph for {self.stock_symbol}")
        plt.xlabel("Date")
        plt.ylabel("Price")
        plt.legend()
        plt.grid()

        buy_signals = self.data[(self.data['Short_MA'] > self.data['Long_MA']) & (self.data['Short_MA'].shift(1) <= self.data['Long_MA'].shift(1))]
        sell_signals = self.data[(self.data['Short_MA'] < self.data['Long_MA']) & (self.data['Short_MA'].shift(1) >= self.data['Long_MA'].shift(1))]

        plt.scatter(buy_signals.index, buy_signals['Close'], label='Buy Signal', marker='^', color='green', s=100)
        plt.scatter(sell_signals.index, sell_signals['Close'], label='Sell Signal', marker='v', color='red', s=100)

        plt.subplot(2, 1, 2)
        plt.plot(self.data['RSI'], label='RSI (14)', color='purple')
        plt.axhline(y=70, color='red', linestyle='--', label='Overbought')
        plt.axhline(y=30, color='green', linestyle='--', label='Oversold')
        plt.title("Relative Strength Index (RSI)")
        plt.xlabel("Date")
        plt.ylabel("RSI Value")
        plt.legend()
        plt.grid()

        plt.tight_layout()
        plt.show()

# Example Usage
if __name__ == "__main__":
    bot = EnhancedTradingBot(stock_symbol="AAPL", start_date="2023-01-01", end_date="2023-12-31")
    bot.fetch_stock_data()
    bot.calculate_indicators()
    bot.plot_enhanced_graph()
